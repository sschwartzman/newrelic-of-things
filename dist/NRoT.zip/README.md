New-Relic-of-Things
===================

An example of how any time series data can be tracked in New Relic Insights. This example collects data from 2 sensors on a Raspberry Pi (temp/humidity &amp; motion) and from the Nest API.
